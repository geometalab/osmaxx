"OSM Arbitrary Excerpt Export" (osmaxx)

The source of worldwide geospatial data for interactive and printed maps and for geospatial data analysis. Cuts out OpenStreetMap data, processes it to geodata and converts it to typical GIS file formats before being prepared for download.

Die weltweite Geodatenquelle für interaktive und gedruckte Karten und für GIS Analyse. OpenStreetMap-Daten ausschneiden, zu Geodaten aufbereiten und als typisches GIS-Fileformat konvertiert abgeben.

Website: http://osmaxx.hsr.ch
Contact: See website.

